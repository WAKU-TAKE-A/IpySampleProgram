# -*- coding: utf-8 -*-

import time

class SamplePyc001:
    def __init__(self):
        self.var_a = 0
        self.var_b = 0
        self.var_num = 100000

    def set(self, a, b):
        self.var_a = a
        self.var_b = b
    
    def set_num(self, n):
        self.var_num = n

    def calc(self):
        start = time.time()
        for i in xrange(self.var_num):
            c = (self.var_a + self.var_b) / 2
        elapsed_time = time.time() - start
        print("Answer is " + str(c) + ". It took " + str(elapsed_time) + " seconds.")

if __name__ == "__main__":
    smp = SamplePyc001()
    smp.set(2, 9)
    smp.set_num(10000000)
    smp.calc()
